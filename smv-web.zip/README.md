# Slick Mobile Valets & Detailing (S.M.V)

Express + EJS + Tailwind site. Reviews and highlights are based on customer feedback you provided in screenshots.  
Google Map embed uses coordinates from your link.

## Quick start

```bash
npm i
npm run dev
# open http://localhost:3000
